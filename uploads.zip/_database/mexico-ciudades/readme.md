# Base de datos de colonias, municipios y estados de todo México.

Esta base de datos en **MySql** es de libre uso y está hecha a partir de la información proporcionada por _Correos de México_. 

La base de datos contiene las siguientes tablas:
- Países (1).
- Estados (32).
- Municipios (2,465).
- Colonias (143,852).

Última actualización 26 de mayo de 2020.



_
Sígueme en Twitter: https://twitter.com/khristoff